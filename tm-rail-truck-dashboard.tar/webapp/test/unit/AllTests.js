sap.ui.define([
	"comwltm/dashboard/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
