sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	'sap/ui/model/BindingMode',
	'sap/ui/model/json/JSONModel',
	'sap/viz/ui5/data/FlattenedDataset',
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format',
	"sap/m/MessageBox",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",

], (Controller, Fragment, BindingMode, JSONModel, FlattenedDataset, ChartFormatter, Format, MessageBox, formatter, Filter, FilterOperator) => {
	"use strict";

	return Controller.extend("com.wl.tm.dashboard.controller.View1", {
		onInit() {
			//function to get the Authorization
			this.apiCalling();
			//initialise graph data model
			var oJsonModel = new sap.ui.model.json.JSONModel([]);
			this.getView().setModel(oJsonModel, "chartData");

		},
		//function to get truck graph data
		graphCallingTruck: function ( ) {
			var oModel = this.getOwnerComponent().getModel("ZTM_BND_E0344_TRK_EDI");
			var aFilter = [];
			var sSelected;
			//adding filters
			aFilter.push(new Filter({
				path: "date_sel",
				operator: FilterOperator.EQ,
				value1: this.getSelectedDate(this.getView().byId("dateSelectTruck").getSelectedKey())
			}));
			if(this.getView().byId("radioTruck").getSelectedIndex() === 0){sSelected="x"}
			else if(this.getView().byId("radioTruck").getSelectedIndex() === 1){sSelected=""}
			else if(this.getView().byId("radioTruck").getSelectedIndex() === 2){sSelected="y"}
			aFilter.push(new Filter({
				path: "By_Carr_prodtype",
				operator: FilterOperator.EQ,
				value1: sSelected
			}));
			sap.ui.core.BusyIndicator.show();
			oModel.read("/ZTM_CDS_I_TRKEDI_BAR_GRAPH",
				{
					urlParameters: {
						"$top": 10
					},
					filters: aFilter,
					success: function (oResponse) { 
						var oJsonModel = this.getView().getModel("chartData");
						oJsonModel.setData(oResponse.results);
						var title;
						var graphTitle=this.getView().byId("radioRail").getSelectedIndex();
						if(graphTitle===0){title="truck_graph_title";}
						else if(graphTitle===1){title="truck_graph_title_car";}
						else if(graphTitle===2){title="truck_graph_title_cc";}
						
						
						this._setAddGraphSettings(this.getView().byId("vizFrame"),title,"truck_cat_axis_lbl", "truck_legend_lbl");

						sap.ui.core.BusyIndicator.hide();
					}.bind(this),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(oError.message);
					}.bind(this)
				});
		},
		//function to change the date range as per filter
		getSelectedDate: function (key) {
			if (key === "0") { return "015"; }
			if (key === "1") { return "030"; }
			if (key === "2") { return "060"; }
			if (key === "3") { return "090"; }
			if (key === "4") { return "180"; }
			if (key === "5") { return "001"; }
		},
		//function to get rail graph data
		graphCallingRail: function () {
			var oModel = this.getOwnerComponent().getModel();
			var aFilter = [];
			//adding filters
			aFilter.push(new Filter({
				path: "date_sel",
				operator: FilterOperator.EQ,
				value1: this.getSelectedDate(this.getView().byId("dateSelectRail").getSelectedKey())
			}));
			aFilter.push(new Filter({
				path: "By_Carr_prodtype",
				operator: FilterOperator.EQ,
				value1: this.getView().byId("radioRail").getSelectedIndex() === 0 ? "x" : ""
			}));
			sap.ui.core.BusyIndicator.show();
			oModel.read("/ZTM_CDS_I_GRAPH_RAIL",
				{
					urlParameters: {
						"$top": 10
					},
					filters: aFilter,
					success: function (oResponse) {
						var oJsonModel = this.getView().getModel("chartData");
						oJsonModel.setData(oResponse.results);
						var graphTitle=this.getView().byId("radioRail").getSelectedIndex()=== 0 ? "rail_graph_title" : "rail_graph_title_car";
						this._setAddGraphSettings(this.getView().byId("vizFramerail"), graphTitle,"rail_cat_axis_lbl", "rail_legend_lbl");
						sap.ui.core.BusyIndicator.hide();
					}.bind(this),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(oError.message);
					}.bind(this)
				});
		},
		//function to get Authorization like rail,truck and both
		apiCalling: function () {
			var sAuthModel = this.getOwnerComponent().getModel("ZTM_BND_TRUCK_RAIL_AUTH");
			var user = sap.ushell.Container.getService("UserInfo").getId();
			//var user = "KKANCHAN";
			sap.ui.core.BusyIndicator.show();
			sAuthModel.read("/Auth(vkorg='',usnam='" + user + "')",
				{
					success: function (oResponse) {
						sap.ui.core.BusyIndicator.hide();
						//checking the Authorization
						this.checkStatus(oResponse);
					}.bind(this),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(oError.message);
					}.bind(this)
				});
		},
		checkStatus: function (oResponse) {
			var sModel = this.getOwnerComponent().getModel("localModel");
			// sModel.setProperty("/action", "both");
			// this.graphCallingTruck();

			// this.getOwnerComponent().getModel("localModel").setProperty("/selectedaction", "truck");
			

			// as per Authorization updating local model
			//truck
			if(oResponse.ztm_auth_de==="01" && oResponse.status==="Authorized"){
				sModel.setProperty("/action","truck");
			this.getOwnerComponent().getModel("localModel").setProperty("/selectedaction", "truck");
			this.graphCallingTruck();
			}
			//rail
			else if(oResponse.ztm_auth_de==="02" && oResponse.status==="Authorized"){
				sModel.setProperty("/action","rail");
			this.getOwnerComponent().getModel("localModel").setProperty("/selectedaction", "rail");
			this.graphCallingRail();
			}
			//both
			else if(oResponse.ztm_auth_de==="03" && oResponse.status==="Authorized"){

				sModel.setProperty("/action","both");
			this.getOwnerComponent().getModel("localModel").setProperty("/selectedaction", "truck");
			this.graphCallingTruck();
			}
			 // not authorized
			else{
			sModel.setProperty("/action", "");
			MessageBox.error(this.changei18n("not_auth"));
			return;
			 }

		},
		 //function to set the graph settings 
		_setAddGraphSettings: function (oVizFrame,sTitle,sCategoryAxisLbl,sLegendLbl) {
			//this.getView().getModel( "chartData").refresh(true); 
			var vizProperties = {
				interaction: {
					zoom: {
						enablement: "disabled"
					},
					selectability: {
						mode: "EXCLUSIVE"
					}
				},
				valueAxis: {
					title: {
						visible: true,
						text:"$"
					},
					visible: true,
					axisLine: {
						visible: true
					},
					label: {
						linesOfWrap: 2,
						visible: true,
						style: {
							fontSize: "10px"
						}
					}
				},
				categoryAxis: {
					title: {
						visible: true ,
						text:this.changei18n(sCategoryAxisLbl)
					},
					label: {
						linesOfWrap: 2,
						rotation: "fixed",
						angle: 0,
						style: {
							fontSize: "12px"
						}
					},
					axisTick: {
						shortTickVisible: false
					}
				},
				title: {
					text: this.changei18n(sTitle),
					visible: true
				},
				legend: {
					visible: true,
					title:{
						text:this.changei18n(sLegendLbl),
						visible:true
					}
				},
				plotArea: {
					colorPalette: ["#007181"],
					gridline: {
						visible: true
					},
					dataLabel: {
						visible: true,
						style: {
							fontWeight: 'bold'
						},
						hideWhenOverlap: false
					} 
				}
			};

			oVizFrame.setVizProperties(vizProperties);
		},

		//rail truck other report navigation function
		onClickButton: function (oEvent) {
			var sValue = oEvent.getSource().getProperty("text"),
				sButton = oEvent.getSource().getProperty("text"),
				sSemanticObject,
				sAction;
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			if (sButton === this.changei18n("rail_invoice_report")) {
				sSemanticObject = "zrailinvoice_report";
				sAction = "display";
			}
			else if (sButton === this.changei18n("rail_invoice_mon")) {
				sSemanticObject = "ztmrailim";
				sAction = "manage";
			}
			else if (sButton === this.changei18n("rail_dashboard_pro")) {
				sSemanticObject = "zreprcsngfailredi410invce";
				sAction = "manage";
			}
			else if (sButton === this.changei18n("truck_invoice_report")) {
				sSemanticObject = "ztrkinvsearch";
				sAction = "manage";
			}
			else if (sButton === this.changei18n("truck_invoice_mon")) {
				sSemanticObject = "ztruckmonitor";
				sAction = "manage";
			}
			else if (sButton === this.changei18n("truck_dashboard_pro")) {
				sSemanticObject = "truckreprocessing";
				sAction = "manage";
			}
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sSemanticObject,
					action: sAction
				}
			})) || ""; // generate the Hash
			var url = window.location.href.split('#')[0] + hash;
			sap.m.URLHelper.redirect(url, true);

		},
		changei18n: function (sText, sPlaceholder) {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n");
			var cText = oResourceBundle.getResourceBundle().getText(sText, sPlaceholder);
			return cText;
		},
		//handler function when the mode is changed : rail or truck
		onModeSelectChange: function (oEvent) {
			var nSelectedIndex = oEvent.getParameter("selectedIndex");
			var mode = nSelectedIndex === 0 ? this.changei18n("truck") : this.changei18n("rail");
			this.getView().getModel("localModel").setProperty("/selectedaction", mode);
			this.getView().getModel("chartData").setData([]);//clear the chart data
			if (mode === this.changei18n("truck")) {
				//api call and set graph setting for truck
				this.graphCallingTruck();
			}
			else {
				//api call and set graph setting for rail
				this.graphCallingRail();
			}
		},


		 
	});
});